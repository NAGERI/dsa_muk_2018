/* global workbox:false */

self.importScripts('/assets/js/vendor/{fileName}')

workbox.precaching.precacheAndRoute([])
